from django.shortcuts import render, redirect
from django.http import HttpResponse
from django.core.mail import send_mail
from django.http import HttpResponseRedirect
from django.urls import reverse
from django.conf import settings
from django.contrib.auth import authenticate, login
from django.contrib import messages
from .models import Student, Professor, Session, ProfessorWeeklySchedule, WeeklyScheduleChoice, Appointment_Request, Door_Status
from django.contrib.auth.models import User
from datetime import datetime, timedelta
from django.utils import timezone

from rest_framework import status
from rest_framework.views import APIView
from rest_framework.response import Response

from django.http import JsonResponse
from django.shortcuts import render, get_object_or_404

"""
sessions:
student (student_name, student_id, student_email)
professor 
    By professor choice (selected_professor)
    By professor login (username)
"""

class DataAPIView(APIView):
    def post(self, request, format=None):

        # Access the received data
        data = request.data

        if 'studentID' not in data:
            return Response({'error': 'missing student id'}, status=status.HTTP_400_BAD_REQUEST)

        try:
            student_id_cleaned = data['studentID'].strip()
            student = Student.objects.get(student_id=student_id_cleaned)

            session = Session(name=student.name, student_id=student.student_id, email=student.email, is_active=True)
            session.save()

            return JsonResponse({'studentExists': True, 'message': 'Student found'})

        except Student.DoesNotExist:
            return JsonResponse({'studentExists': False, 'message': 'Student not found', 'ID': student_id_cleaned})


    def get(self, request, pname, format=None):
        prof = Professor.objects.get(name=pname)

        return Response(prof.status)
    

class DoorStatusAPIView(APIView):
    def post(self, request, format=None):
        # Access the received data
        data = request.data
        print("HERE: ", data)
        if 'professorName' not in data:
            return Response({'error': 'Missing required fields'}, status=status.HTTP_400_BAD_REQUEST)

        try:
            professor_name_cleaned = data['professorName'].strip()

            professor = Professor.objects.get(name=professor_name_cleaned)
            status = Door_Status.objects.get(professor=professor)
            status.is_door_open = False
            status.save()
            
            return JsonResponse({'success': True, 'message': 'Door status updated successfully'})

        except Professor.DoesNotExist:
            return JsonResponse({'success': False, 'message': 'Professor not found', 'professorName': data['professorName']})
    
    
    
    
    
    def get(self, request, pname, format=None):
        try:
            # Find the professor by name
            prof = Professor.objects.get(name=pname)
            
            # Retrieve the door status for the professor
            door_status = Door_Status.objects.get(professor=prof)

            if door_status.is_door_open:
                return HttpResponse('true', content_type='text/plain')
            else:
                return HttpResponse('false', content_type='text/plain')
        except Professor.DoesNotExist:
            return Response({'error': 'Professor not found'}, status=status.HTTP_404_NOT_FOUND)
        except Door_Status.DoesNotExist:
            # In case there is no door status linked to the professor
            return Response({'error': 'Door status not found for this professor'}, status=status.HTTP_404_NOT_FOUND)

        
            

        



def check_condition(request):
    try:
        latest_session = Session.objects.all().order_by('-created_at').first()
        now = timezone.now()

        time_difference = now - latest_session.created_at
        
        if time_difference > timedelta(minutes=1):
            return JsonResponse({'redirect': False})

        else:         
            if latest_session.is_active is True:
                # saving information of student in request session
                request.session['student_id'] = latest_session.student_id
                request.session['student_name'] = latest_session.name
                request.session['student_email'] = latest_session.email

                return JsonResponse({'redirect': True, 'url': '/booking/'})
            else:
                return JsonResponse({'redirect': False}) 
    except:
        return JsonResponse({'redirect': False})


def booking_page(request):

    try:
        
        if request.method == 'GET':
            # Get the selected professor's username from the request
            professorusername = request.GET.get('professor_name', '')
            print('Received professorusername:', professorusername)

            # Fetch the professor's schedule based on the professorusername
            professor, professor_schedule_data = get_professor_schedule_data(professorusername)

            request.session['selected_professor'] = professor.user.username 

            return JsonResponse({'professor_schedule_data': professor_schedule_data})
        
        elif request.method == 'POST':
            # Handle the form submission
            selected_time = request.POST.get('selected_time', '')
            time = int(selected_time)
            student_message = request.POST.get('student_message', '')

            # change this to session 
            # latest_session = Session.objects.all().order_by('-created_at').first()
            # student = Student.objects.get(student_id=latest_session.student_id)

            student_info = request.session.get('student_email')
            print('student in session: ', student_info)
            student = Student.objects.get(email=student_info)


            period = (time - 1) % 5
            day = (time - 1) // 5

            week_day = code_to_day_converter(day)

            selected_professor_info = request.session.get('selected_professor')
            selected_professor = get_professor_by_username(selected_professor_info)

            schedule = ProfessorWeeklySchedule.objects.filter(professor=selected_professor)

            selected_section = schedule.filter(choice__day=week_day, choice__period=period+1).first()

            # If there are existing schedules, update the choice; otherwise, create a new one
            if selected_section is None:
                print('HEY')
                req = Appointment_Request(
                    professor = selected_professor,
                    student = student,
                    request_day = day,
                    request_period = period+1,
                    student_message = student_message
                )
                req.save()

            # print('Time: ', time)
            # print('Day: ', day)
            # print('WDay: ', week_day)
            # print('Period: ', period)
            # print(selected_section.choice.description)


            return render(request, 'booking.html')
        
    except Exception as e:
        print('Error:', e)
        return render(request, 'booking.html')



def get_professor_schedule_data(professorusername):
    professor = get_object_or_404(Professor, user__username=professorusername)  
    # Fetch the professor's schedule data
    periods = [1, 2, 3, 4, 5]
    days = ['Wednesday', 'Tuesday', 'Monday', 'Sunday', 'Saturday']
    schedule_data = []
    counter=0
    for period in periods:
        schedule_row = []
        for day in days:
            professor_schedule = ProfessorWeeklySchedule.objects.filter(
                choice__day=day,
                choice__period=period,
                professor=professor
            ).order_by('-id').first()
            if not professor_schedule:
                counter+=1
            if professor_schedule:
                schedule_row.append({
                    'description': professor_schedule.choice.description,
                })
            else:
                schedule_row.append({
                    'description': f"free {counter}",
                })
            
                

        schedule_data.append(schedule_row)

    return professor, schedule_data



def get_professor_by_username(username):
    user = get_object_or_404(User, username=username)
    return get_object_or_404(Professor, user=user)


def update_schedule(request):
    if request.method == 'POST':
        day = int(request.POST.get('day'))
        period = int(request.POST.get('period')) + 1
        new_description = request.POST.get('new_description')

        actualDay = code_to_day_converter(day)

        professor = get_professor_by_username(request.session.get('username'))

        # Create a new schedule choice if it doesn't exist
        schedule_choice, created = WeeklyScheduleChoice.objects.get_or_create(day=actualDay, period=period, description=new_description)

        if not created:
            # Handle duplication
            schedule_choice = WeeklyScheduleChoice.objects.filter(day=actualDay, period=period, description=new_description).first()

        # Filter ProfessorWeeklySchedule objects for the professor and the chosen choice
        existing_schedules = ProfessorWeeklySchedule.objects.filter(professor=professor, choice=schedule_choice)

        # If there are existing schedules, update the choice; otherwise, create a new one
        if existing_schedules.exists():
            existing_schedules.update(choice=schedule_choice)
        else:
            ProfessorWeeklySchedule.objects.create(professor=professor, choice=schedule_choice)

        return JsonResponse({'status': 'success'})

    return JsonResponse({'status': 'error'})


def code_to_day_converter(day_index):
    if day_index == 0:
        return 'Wednesday'
    elif day_index == 1:
        return 'Tuesday'
    elif day_index == 2:
        return 'Monday'
    elif day_index == 3:
        return 'Sunday'
    else:
        return 'Saturday'
    

def code_to_time_converter(time_index):
    if time_index == 1:
        return '8 am - 10 am'
    elif time_index == 2:
        return '10 am - 12 pm'
    elif time_index == 3:
        return '12 pm - 2 pm'
    elif time_index == 4:
        return '2 pm - 4 pm'
    else:
        return '4 pm - 6 pm'





def send_email(student_name, professor_name, request_day, request_period, recipient):

    SUBJECT = 'Appointment Request Approval'
    SENDER = 'ferdowsi.proff.inc@gmail.com'

    actual_day = code_to_day_converter(request_day)
    actual_time =  code_to_time_converter(request_period)

    message = f"""Dear {student_name}\nYour Appointment Request Approved by Dr {professor_name} on {actual_day} at {actual_time}.\nGood Luck🍀"""
    recipient_list = [recipient]
    
    send_mail(SUBJECT, message, SENDER, recipient_list, fail_silently=False)

    return True


def login_page(request):
    if request.method == "POST":
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            request.session['username'] = username
            return redirect('professor')
        else:
            messages.success(request, ("There Was An Error Logging In, Try Again..."))	
            return redirect('professor_login')	
    else:
        return render(request, 'login.html')



def main_page(request):

    professors = Professor.objects.all()
    context = {'professors': professors}

    if request.method == 'POST':
        name = request.POST.get('name')
        email = request.POST.get('email')
        
        if not Student.objects.filter(email=email).exists():
            student = Student(name=name, email=email)
            student.save()

            # saving information of student in request session
            request.session['student_name'] = name
            request.session['student_email'] = email

            return redirect('booking')
    else:
        return render(request, 'main.html', context)







def professor_page(request):
    # Get the username from the session
    username = request.session.get('username')
    print('USERNAME: ', username)
    # Get the professor's schedule data
    p, schedule_data = get_professor_schedule_data(username)

    professor = get_professor_by_username(username)

    # Fetch the appointment requests for the current professor
    pending_appointment_requests = Appointment_Request.objects.filter(professor=professor, status='Pending')
    approved_appointment_requests = Appointment_Request.objects.filter(professor=professor, status='Approved')

    if request.method == 'POST':
        form_type = request.POST.get('form_type')
        
        if form_type == 'update_schedule':
            return update_schedule(request)

        # status selection
        elif form_type == 'status_form':
            status = request.POST.get('status')
            
            professor.status = status
            professor.save()
            print('prof status: ', status)

        # Handle accept and reject request forms
        elif form_type in ['accept_request_form', 'reject_request_form']:
            request_id = request.POST.get('request_id')
            appointment_request = Appointment_Request.objects.get(id=request_id, professor=professor)
            
            if form_type == 'accept_request_form':
                appointment_request.status = 'Approved'
                student_name = appointment_request.student.name
                student_email = appointment_request.student.email
                appointment_day = appointment_request.request_day 
                appointment_period = appointment_request.request_period

                send_email(student_name, professor.name, appointment_day, appointment_period, student_email)

            elif form_type == 'reject_request_form':
                appointment_request.status = 'Rejected'
            
            appointment_request.save()            
        
        # door status
        elif form_type == 'open_door_form':
            door_status = Door_Status.objects.get(professor=professor)
            door_status.is_door_open = True
            door_status.save()

        elif form_type == 'accept_request_form':
            req = Appointment_Request.objects.get(professor=professor)
            door_status.is_door_open = True
            door_status.save()



    # Pass the schedule data and appointment requests to the template context
    context = {
        'status': professor.status,
        'schedule_data': schedule_data,
        'appointment_requests': pending_appointment_requests,
        'approved_appointment_requests' : approved_appointment_requests
    }

    return render(request, 'schedule.html', context)




