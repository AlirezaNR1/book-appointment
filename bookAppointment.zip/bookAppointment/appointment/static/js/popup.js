document.getElementById('openPopupBtn').addEventListener('click', function(event) {
    event.preventDefault();
    document.getElementById('popup').style.display = 'block';
  });
  
  document.getElementById('closePopupBtn').addEventListener('click', function() {
    document.getElementById('popup').style.display = 'none';
  });
  

